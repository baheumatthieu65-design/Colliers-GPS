import { createClient } from '@supabase/supabase-js';
import {
  githubReadJson,
  githubJsonCache,
  GITHUB_READ_CACHE_MS,
  readZonesConfig,
  pointInsideZone,
  evaluateZoneExit,
  evaluateBatteryLow,
} from './_lib/positionChecks';
import type { GithubZoneConfig, ZonesConfigFile } from './_lib/positionChecks';

/**
 * Pâtur'GPS V12
 *
 * Architecture:
 * - GitHub = source of truth for application configuration (collars + zones).
 * - Supabase = live/technical data, history, alerts and PUSH commands.
 * - Vercel = secure gateway between the app, GitHub and Supabase.
 * - MQTT delivery is prepared through the command queue; the MQTT worker can
 *   consume pending command_targets and publish them to the BG95 at wake-up.
 */

type AnyReq = {
  method?: string;
  body?: any;
  query?: Record<string, any>;
  url?: string;
  headers?: Record<string, string | string[] | undefined>;
};

type AnyRes = {
  status: (code: number) => AnyRes;
  json: (body: any) => void;
  setHeader: (name: string, value: string) => void;
  end: () => void;
};

type GithubFile = {
  sha: string;
  content: string;
};

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const githubToken = process.env.GITHUB_TOKEN;
const githubOwner = process.env.GITHUB_REPO_OWNER || 'baheumatthieu65-design';
const githubRepo = process.env.GITHUB_REPO_NAME || 'Colliers-GPS';
const githubBranch = process.env.GITHUB_BRANCH || 'main';
const githubApiBase = 'https://api.github.com';

const COLLARS_CONFIG_PATH = 'config/collars.json';
const ZONES_CONFIG_PATH = 'config/zones.json';

function cors(res: AnyRes) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
}

function getPath(req: AnyReq) {
  // Sur Vercel, query.path peut ne contenir qu'une partie du catch-all.
  // L'URL réelle est donc prioritaire : elle garantit /api/collars/<id>
  // et /api/zones/<id> pour PUT/DELETE.
  const rawUrl = String(req.url || '');
  let pathOnly = rawUrl.split('?')[0];

  // Si le runtime fournit une URL absolue, ne conserver que son pathname.
  if (/^https?:\/\//i.test(pathOnly)) {
    try {
      pathOnly = new URL(pathOnly).pathname;
    } catch {
      // On retombe sur le nettoyage classique ci-dessous.
    }
  }

  const fromUrl = pathOnly
    .replace(/^\/?api\/?/, '')
    .replace(/^\/+|\/+$/g, '');

  if (fromUrl) {
    try { return decodeURIComponent(fromUrl); } catch { return fromUrl; }
  }

  if (req.query && req.query.path !== undefined) {
    const rawPath = Array.isArray(req.query.path)
      ? req.query.path.join('/')
      : String(req.query.path);
    const cleaned = rawPath.replace(/^\/?api\/?/, '').replace(/^\/+|\/+$/g, '');
    try { return decodeURIComponent(cleaned); } catch { return cleaned; }
  }

  return '';
}

function getQuery(req: AnyReq) {
  const result: Record<string, string> = {};
  if (req.query) {
    for (const [key, value] of Object.entries(req.query)) {
      if (key === 'path') continue;
      if (Array.isArray(value)) result[key] = String(value[0] ?? '');
      else if (value != null) result[key] = String(value);
    }
    return result;
  }

  const rawUrl = String(req.url || '');
  const queryString = rawUrl.includes('?') ? rawUrl.slice(rawUrl.indexOf('?') + 1) : '';
  return Object.fromEntries(new URLSearchParams(queryString).entries());
}

function signalQuality(signal: number | null | undefined) {
  if (signal == null) return 'Inconnu';
  if (signal >= 75) return 'Excellent';
  if (signal >= 50) return 'Bon';
  if (signal >= 25) return 'Moyen';
  return 'Faible';
}

function errorText(value: any): string {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  if (value instanceof Error) return value.message || '';
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  try {
    const json = JSON.stringify(value);
    return json && json !== '{}' ? json : '';
  } catch {
    return '';
  }
}

function normalizeError(details: any) {
  if (details == null) return null;
  if (typeof details === 'string') return details;
  if (details instanceof Error) {
    return { message: details.message || 'Erreur inconnue.' };
  }

  const message = errorText(details.message) || errorText(details.details) || errorText(details.hint) || errorText(details) || 'Erreur inconnue.';
  return {
    message,
    code: errorText(details.code) || undefined,
    details: errorText(details.details) || undefined,
    hint: errorText(details.hint) || undefined,
  };
}

function error(res: AnyRes, status: number, message: string, details?: any) {
  const normalized = normalizeError(details);
  console.error('[PaturGPS API]', message, normalized || '');
  return res.status(status).json({ ok: false, error: message, details: normalized });
}

function requireGithubWriteAccess() {
  if (!githubToken) {
    throw new Error('GITHUB_TOKEN manque sur Vercel : les modifications GitHub sont désactivées.');
  }
}

function githubHeaders() {
  return {
    Accept: 'application/vnd.github+json',
    Authorization: `Bearer ${githubToken}`,
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
  };
}

function githubContentsUrl(path: string) {
  return `${githubApiBase}/repos/${encodeURIComponent(githubOwner)}/${encodeURIComponent(githubRepo)}/contents/${path
    .split('/')
    .map(encodeURIComponent)
    .join('/')}?ref=${encodeURIComponent(githubBranch)}`;
}

function decodeGithubContent(encoded: string) {
  return Buffer.from(encoded.replace(/\n/g, ''), 'base64').toString('utf8');
}

// NOTE : githubReadJson + son cache mémoire (githubJsonCache) vivent
// maintenant dans ./_lib/positionChecks.ts, partagés avec api/positions-check.ts.

async function githubReadFile(path: string): Promise<GithubFile | null> {
  requireGithubWriteAccess();
  const response = await fetch(githubContentsUrl(path), {
    headers: githubHeaders(),
    cache: 'no-store',
  });

  if (response.status === 404) return null;
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`GitHub lecture ${path} impossible (${response.status}) : ${text.slice(0, 300)}`);
  }

  const payload = await response.json();
  return {
    sha: payload.sha,
    content: decodeGithubContent(String(payload.content || '')),
  };
}

async function githubWriteJson(path: string, value: unknown, message: string) {
  requireGithubWriteAccess();

  const current = await githubReadFile(path);
  const content = Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8').toString('base64');
  const body: Record<string, any> = {
    message,
    content,
    branch: githubBranch,
  };
  if (current?.sha) body.sha = current.sha;

  const response = await fetch(`${githubApiBase}/repos/${encodeURIComponent(githubOwner)}/${encodeURIComponent(githubRepo)}/contents/${path
    .split('/')
    .map(encodeURIComponent)
    .join('/')}`, {
    method: 'PUT',
    headers: githubHeaders(),
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`GitHub écriture ${path} impossible (${response.status}) : ${text.slice(0, 500)}`);
  }

  const payload = await response.json();
  // Une écriture réussie doit invalider/remplacer immédiatement le cache de
  // lecture. Sinon un GET suivant peut servir l'ancienne configuration pendant
  // jusqu'à 60 s et donner l'impression qu'un collier/une zone n'a pas été
  // enregistré(e) ou supprimé(e).
  githubJsonCache.set(path, {
    data: value,
    sha: payload?.content?.sha || null,
    expiresAt: Date.now() + GITHUB_READ_CACHE_MS,
  });

  return payload;
}

async function githubDeleteFile(path: string, message: string) {
  requireGithubWriteAccess();
  const current = await githubReadFile(path);
  if (!current) return { deleted: false };

  const response = await fetch(`${githubApiBase}/repos/${encodeURIComponent(githubOwner)}/${encodeURIComponent(githubRepo)}/contents/${path
    .split('/')
    .map(encodeURIComponent)
    .join('/')}`, {
    method: 'DELETE',
    headers: githubHeaders(),
    body: JSON.stringify({ message, sha: current.sha, branch: githubBranch }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`GitHub suppression ${path} impossible (${response.status}) : ${text.slice(0, 500)}`);
  }

  return { deleted: true };
}

type GithubCollarConfig = {
  id: string;
  sheepName: string;
  collarNumber: string;
  animalNumber?: string;
  color?: string;
  mode?: 'simulation' | 'real';
  status?: 'active' | 'inactive' | 'maintenance';
  notes?: string;
  activeZoneId?: string | null;
  baseTransmissionMinutes?: number;
};

// GithubZoneConfig / ZonesConfigFile sont importés depuis ./_lib/positionChecks.

type CollarsConfigFile = { version: number; collars: GithubCollarConfig[] };

const fallbackCollarsConfig: CollarsConfigFile = {
  version: 1,
  collars: [{
    id: 'ff843b96-8b9d-46e8-95bb-253e40f94d97',
    sheepName: 'Fanny',
    collarNumber: 'COL-1',
    color: '#EF4444',
    mode: 'simulation',
    status: 'active',
    activeZoneId: '6db4ea95-c17a-47f5-92d6-5c66e2892c0f',
    baseTransmissionMinutes: 60,
    animalNumber: '456-244',
  }],
};

const emptyCollarsConfig: CollarsConfigFile = fallbackCollarsConfig;

async function readCollarsConfig() {
  return githubReadJson<CollarsConfigFile>(COLLARS_CONFIG_PATH, fallbackCollarsConfig);
}

// readZonesConfig est importé depuis ./_lib/positionChecks (mêmes données de
// secours, partagées avec api/positions-check.ts).

async function refreshExpiredPushCadence(supabase: any, rows: any[]) {
  const now = Date.now();
  return Promise.all((rows || []).map(async (row: any) => {
    const expiresAt = row?.push_expires_at ? Date.parse(String(row.push_expires_at)) : NaN;
    const standard = Number(row?.standard_cadence_seconds);
    if (Number.isFinite(expiresAt) && expiresAt <= now && Number.isFinite(standard) && standard > 0) {
      const { data, error: dbError } = await supabase
        .from('collars')
        .update({ active_cadence_seconds: Math.max(60, Math.round(standard)), push_expires_at: null })
        .eq('id', row.id)
        .select('*')
        .single();
      if (dbError) throw new Error(`Impossible de terminer le PUSH expiré du collier ${row.id} : ${dbError.message}`);
      return data || { ...row, active_cadence_seconds: Math.max(60, Math.round(standard)), push_expires_at: null };
    }
    return row;
  }));
}

// Calcule le statut réel (dans/hors zone) à partir de la dernière position GPS
// connue et de la ou des patatoïdes affectées au collier. Avant ce correctif,
// le statut était figé à 'inside_zone' : le point rouge "hors zone" sur la
// carte et le bandeau d'alerte sur la fiche collier ne s'allumaient donc
// jamais, même quand la brebis était réellement dehors.
function computeCollarStatus(
  config: GithubCollarConfig,
  latestPosition: { latitude: number; longitude: number } | undefined,
  assignedZones: any[],
) {
  if (config.status === 'inactive') return 'offline';
  if (!latestPosition || !assignedZones.length) return 'inside_zone';
  const inside = assignedZones.some((zone) => pointInsideZone(latestPosition.latitude, latestPosition.longitude, zone));
  return inside ? 'inside_zone' : 'out_of_zone';
}

function mapCollar(
  config: GithubCollarConfig,
  row: any,
  assignedZoneId?: string | null,
  latestPosition?: { latitude: number; longitude: number; recordedAt?: string | null; batteryPercent?: number | null },
  assignedZones: any[] = [],
) {
  return {
    id: config.id,
    sheepName: config.sheepName,
    collarNumber: config.collarNumber,
    animalNumber: config.animalNumber || undefined,
    color: config.color || '#5A6F4E',
    // La batterie affichée doit correspondre à la même dernière trame GPS que
    // la position affichée, et non à une valeur potentiellement ancienne dans collars.
    batteryLevel: latestPosition ? (latestPosition.batteryPercent ?? null) : (row?.battery_percent ?? null),
    signalQuality: signalQuality(row?.signal_strength),
    lastUpdate: latestPosition?.recordedAt || row?.last_seen || row?.updated_at || row?.created_at || new Date().toISOString(),
    // Aucune position fictive : sans position GPS réelle, les coordonnées sont absentes.
    currentLat: latestPosition?.latitude,
    currentLng: latestPosition?.longitude,
    status: computeCollarStatus(config, latestPosition, assignedZones),
    activeZoneId: assignedZoneId || config.activeZoneId || undefined,
    pushMode: (() => {
      const standardCadenceSeconds = Number(row?.standard_cadence_seconds) > 0
        ? Math.max(60, Math.round(Number(row.standard_cadence_seconds)))
        : (Number(config.baseTransmissionMinutes) > 0 ? Math.max(60, Math.round(Number(config.baseTransmissionMinutes) * 60)) : 1800);
      const activeCadenceSeconds = Number(row?.active_cadence_seconds) > 0
        ? Math.max(60, Math.round(Number(row.active_cadence_seconds)))
        : standardCadenceSeconds;
      const expiresAt = row?.push_expires_at || null;
      const pushActive = Boolean(expiresAt && Date.parse(String(expiresAt)) > Date.now());
      return {
        active: pushActive,
        intervalSeconds: pushActive ? activeCadenceSeconds : standardCadenceSeconds,
        expiresAt: pushActive ? expiresAt : null,
        durationMinutes: pushActive && row?.push_duration_minutes ? Number(row.push_duration_minutes) : 0,
      };
    })(),
    // Ces données viennent de Supabase, pas de la configuration GitHub.
    imei: row?.imei || undefined,
    iccid: row?.iccid || undefined,
    simPhone: row?.sim_phone || undefined,
    mode: config.mode || row?.mode || 'simulation',
    notes: config.notes || undefined,
    standardCadenceSeconds: Number(row?.standard_cadence_seconds) > 0 ? Math.max(60, Math.round(Number(row.standard_cadence_seconds))) : undefined,
    activeCadenceSeconds: Number(row?.active_cadence_seconds) > 0 ? Math.max(60, Math.round(Number(row.active_cadence_seconds))) : undefined,
    pushExpiresAt: row?.push_expires_at || null,
    baseTransmissionMinutes: Number(row?.standard_cadence_seconds) > 0
      ? Math.max(1, Math.round(Number(row.standard_cadence_seconds) / 60))
      : (Number(config.baseTransmissionMinutes) > 0 ? Number(config.baseTransmissionMinutes) : 30),
  };
}

function mapZone(config: GithubZoneConfig) {
  return {
    id: config.id,
    name: config.name,
    description: config.description || '',
    centerLat: config.centerLat,
    centerLng: config.centerLng,
    radiusMeters: config.radiusMeters || 500,
    polygonCoords: config.polygonCoords || undefined,
    assignedCollarIds: config.assignedCollarIds || [],
    color: config.color || '#5A6F4E',
    active: config.active !== false,
    alertOnExit: config.alertOnExit !== false,
    fillVisible: config.fillVisible !== false,
  };
}

async function getSupabaseCollarMap(supabase: any, ids: string[]) {
  if (!ids.length) return new Map<string, any>();
  const { data, error: dbError } = await supabase.from('collars').select('*').in('id', ids);
  if (dbError) throw new Error(`Erreur lecture données techniques des colliers : ${dbError.message}`);
  return new Map((data || []).map((row: any) => [row.id, row]));
}

// Dernière position GPS réelle de chaque collier.
// La table positions est la source de vérité pour l'emplacement affiché sur la carte.
async function getLatestPositionMap(supabase: any, ids: string[]) {
  const result = new Map<string, any>();
  if (!ids.length) return result;

  // Une requête limitée à 1 ligne par collier garantit de prendre la dernière
  // donnée GPS de chaque collier, même si positions contient beaucoup d'historique.
  const latestRows = await Promise.all(ids.map(async (collarId) => {
    const { data, error: dbError } = await supabase
      .from('positions')
      .select('collar_id, latitude, longitude, recorded_at, battery_percent')
      .eq('collar_id', collarId)
      .not('latitude', 'is', null)
      .not('longitude', 'is', null)
      .order('recorded_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (dbError) {
      throw new Error(`Erreur lecture de la dernière position GPS du collier ${collarId} : ${dbError.message}`);
    }

    return data;
  }));

  for (const position of latestRows) {
    const collarId = String(position?.collar_id || '');
    if (!collarId) continue;

    const latitude = Number(position?.latitude);
    const longitude = Number(position?.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) continue;

    result.set(collarId, {
      latitude,
      longitude,
      recordedAt: position?.recorded_at || null,
      batteryPercent: position?.battery_percent == null ? null : Number(position.battery_percent),
    });
  }

  return result;
}

async function mirrorZoneToSupabase(supabase: any, zone: GithubZoneConfig) {
  const row = {
    id: zone.id,
    name: zone.name,
    type: zone.polygonCoords?.length >= 3 ? 'polygon' : 'circle',
    center_latitude: zone.centerLat,
    center_longitude: zone.centerLng,
    radius_meters: zone.radiusMeters || 500,
    polygon_coords: zone.polygonCoords || null,
    color: zone.color || '#5A6F4E',
    enabled: zone.active !== false,
    notes: zone.description || '',
  };

  const { error: dbError } = await supabase.from('zones').upsert(row, { onConflict: 'id' });
  if (dbError) throw new Error(`Miroir Supabase de la clôture impossible : ${dbError.message}`);

  await supabase.from('collar_zones').delete().eq('zone_id', zone.id);
  const ids = (zone.assignedCollarIds || []).filter(Boolean);
  if (ids.length) {
    const { error: linkError } = await supabase.from('collar_zones').upsert(
      ids.map((collarId) => ({ collar_id: collarId, zone_id: zone.id, enabled: true })),
      { onConflict: 'collar_id,zone_id' }
    );
    if (linkError) throw new Error(`Affectation Supabase de la clôture impossible : ${linkError.message}`);
  }
}

async function mirrorCollarToSupabase(supabase: any, config: GithubCollarConfig, body: any = {}) {
  const row = {
    id: config.id,
    name: config.sheepName,
    internal_code: config.collarNumber,
    animal_name: config.sheepName,
    animal_number: config.animalNumber || null,
    imei: body.imei || null,
    iccid: body.iccid || null,
    sim_phone: body.simPhone || null,
    mode: config.mode === 'real' ? 'real' : 'simulation',
    status: config.status || 'active',
    color: config.color || '#5A6F4E',
    notes: config.notes || null,
    standard_cadence_seconds: Number(config.baseTransmissionMinutes) > 0
      ? Math.max(60, Math.round(Number(config.baseTransmissionMinutes) * 60))
      : 1800,
    active_cadence_seconds: Number(config.baseTransmissionMinutes) > 0
      ? Math.max(60, Math.round(Number(config.baseTransmissionMinutes) * 60))
      : 1800,
    push_expires_at: null,
  };

  const { data, error: dbError } = await supabase
    .from('collars')
    .upsert(row, { onConflict: 'id' })
    .select('*')
    .single();

  if (dbError) throw new Error(`Miroir Supabase du collier impossible : ${dbError.message}`);
  return data;
}


async function queueStandardCadenceCommand(supabase: any, collar: any, cadenceSecondsInput: number) {
  const cadenceSeconds = Number(cadenceSecondsInput);
  if (!Number.isFinite(cadenceSeconds) || cadenceSeconds < 60) return null;
  const normalizedCadenceSeconds = Math.max(60, Math.round(cadenceSeconds));
  const payload = {
    type: 'set_standard_cadence',
    cadenceMinutes: normalizedCadenceSeconds / 60,
    cadenceSeconds: normalizedCadenceSeconds,
    delivery: 'next_wakeup',
    instruction: 'Au prochain réveil, appliquer cette cadence standard jusqu’à nouvelle modification ou PUSH temporaire.',
  };

  const { data: command, error: commandError } = await supabase.from('commands').insert({
    command_type: 'configure',
    cadence_seconds: normalizedCadenceSeconds,
    duration_minutes: null,
    target_mode: 'selected',
    status: 'pending',
    payload,
  }).select('*').single();
  if (commandError) throw new Error(`Impossible de créer la commande de cadence standard : ${commandError.message}`);

  const targetRow = {
    command_id: command.id,
    collar_id: collar.id,
    status: 'pending',
    delivery_status: 'queued',
    mqtt_topic: collar.imei ? `paturgps/${collar.imei}/command` : null,
    mqtt_payload: { ...payload, collarId: collar.id, imei: collar.imei || null },
  };
  const { error: targetError } = await supabase.from('command_targets').insert(targetRow);
  if (targetError) throw new Error(`Commande de cadence créée mais cible impossible à enregistrer : ${targetError.message}`);
  return command;
}


// pointInPolygon / distanceMeters / pointInsideZone / getAssignedZonesForCollar
// / evaluateZoneExit / evaluateBatteryLow sont importés depuis
// ./_lib/positionChecks.ts, partagés avec api/positions-check.ts (déclenché
// par le Database Webhook Supabase sur `positions`, y compris pour les
// positions écrites directement par l'automatisation Zapier/Make/n8n).

type IngestPositionInput = {
  latitude: number;
  longitude: number;
  altitude?: number | null;
  accuracy?: number | null;
  speed?: number | null;
  heading?: number | null;
  batteryPercent?: number | null;
  signalStrength?: number | null;
  recordedAt?: string | null;
  source: 'manual' | 'simulation' | 'gps' | 'mqtt';
};

// Point d'entrée UNIQUE pour toute nouvelle position, qu'elle vienne du BG95
// (MQTT, /api/telemetry) ou d'une saisie manuelle dans l'app (/api/collars/:id/position).
// Avant ce correctif, les positions ajoutées directement dans Supabase (hors
// API) ne déclenchaient JAMAIS evaluateZoneExit : aucune alerte hors-zone
// n'était donc jamais créée pour ces positions-là.
async function ingestPosition(supabase: any, collar: any, input: IngestPositionInput) {
  const recordedAt = input.recordedAt || new Date().toISOString();
  const { data: position, error: positionError } = await supabase.from('positions').insert({
    collar_id: collar.id,
    latitude: input.latitude,
    longitude: input.longitude,
    altitude: input.altitude ?? null,
    accuracy: input.accuracy ?? null,
    speed: input.speed ?? null,
    heading: input.heading ?? null,
    battery_percent: input.batteryPercent ?? null,
    signal_strength: input.signalStrength ?? null,
    source: input.source,
    recorded_at: recordedAt,
  }).select('*').single();
  if (positionError) throw new Error(`Impossible de stocker la position : ${positionError.message}`);

  const { error: collarUpdateError } = await supabase.from('collars').update({
    last_latitude: input.latitude,
    last_longitude: input.longitude,
    last_altitude: input.altitude ?? null,
    last_accuracy: input.accuracy ?? null,
    battery_percent: input.batteryPercent ?? collar.battery_percent,
    signal_strength: input.signalStrength ?? collar.signal_strength,
    last_seen: recordedAt,
  }).eq('id', collar.id);
  if (collarUpdateError) throw new Error(`Position enregistrée mais mise à jour du collier impossible : ${collarUpdateError.message}`);

  // Les deux contrôles tournent à chaque nouvelle position, peu importe la
  // source. L'insertion dans `alerts` déclenche ensuite le Web Push Supabase
  // (webhook côté dashboard Supabase, à configurer séparément).
  let zoneCheck: any = { checked: false, inside: true, alerted: false };
  try {
    zoneCheck = await evaluateZoneExit(supabase, collar, input.latitude, input.longitude, recordedAt);
  } catch (zoneError: any) {
    // La position reste valide même si le contrôle de zone échoue : on ne
    // perd jamais la télémétrie à cause du système d'alerte.
    console.error('[PaturGPS API] Contrôle hors zone échoué', zoneError?.message || zoneError);
  }

  let batteryCheck: any = { checked: false, low: false, alerted: false };
  try {
    batteryCheck = await evaluateBatteryLow(supabase, collar, input.latitude, input.longitude, input.batteryPercent, recordedAt);
  } catch (batteryError: any) {
    console.error('[PaturGPS API] Contrôle batterie faible échoué', batteryError?.message || batteryError);
  }

  return { position, zoneCheck, batteryCheck };
}

export default async function handler(req: AnyReq, res: AnyRes) {
  cors(res);

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (!supabaseUrl || !serviceRoleKey) {
    return error(res, 500, 'Variables Supabase manquantes sur Vercel.');
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const path = getPath(req);
  const query = getQuery(req);
  const method = req.method || 'GET';

  try {
    // ---------------- HEALTH / CONFIG ----------------
    if (path === 'health' && method === 'GET') {
      const [{ error: dbError }, github] = await Promise.all([
        supabase.from('collars').select('id').limit(1),
        githubReadJson<CollarsConfigFile>(COLLARS_CONFIG_PATH, emptyCollarsConfig),
      ]);
      if (dbError) return error(res, 500, 'Supabase inaccessible.', dbError.message);
      return res.status(200).json({
        ok: true,
        service: 'patur-gps-api-v12',
        github: github.fromGithub,
        githubWriteConfigured: Boolean(githubToken),
      });
    }

    // ---------------- COLLARS : GITHUB + SUPABASE ----------------
    if (path === 'collars' && method === 'GET') {
      const config = await readCollarsConfig();
      const ids = config.data.collars.map((c) => c.id);
      let [rows, latestPositions] = await Promise.all([
        getSupabaseCollarMap(supabase, ids),
        getLatestPositionMap(supabase, ids),
      ]);
      const refreshedRows = await refreshExpiredPushCadence(supabase, Array.from(rows.values()));
      rows = new Map(refreshedRows.map((row: any) => [row.id, row]));

      const zoneByCollar = new Map<string, string>();
      // Toutes les zones affectées à chaque collier (un collier peut être dans
      // plusieurs patatoïdes) : nécessaire pour calculer le vrai statut
      // dans/hors zone ci-dessous, au lieu de le figer à 'inside_zone'.
      const zonesByCollar = new Map<string, any[]>();
      const zones = await readZonesConfig();
      for (const zone of zones.data.zones) {
        if (zone.active === false) continue;
        const zoneForStatus = {
          type: zone.polygonCoords && zone.polygonCoords.length >= 3 ? 'polygon' : 'circle',
          polygon_coords: zone.polygonCoords || null,
          center_latitude: zone.centerLat,
          center_longitude: zone.centerLng,
          radius_meters: zone.radiusMeters,
          enabled: true,
        };
        for (const collarId of zone.assignedCollarIds || []) {
          zoneByCollar.set(collarId, zone.id);
          const list = zonesByCollar.get(collarId) || [];
          list.push(zoneForStatus);
          zonesByCollar.set(collarId, list);
        }
      }

      return res.status(200).json(
        config.data.collars.map((c) =>
          mapCollar(c, rows.get(c.id), zoneByCollar.get(c.id), latestPositions.get(c.id), zonesByCollar.get(c.id) || [])
        )
      );
    }

    if (path === 'collars' && method === 'POST') {
      const body = req.body || {};
      if (!body.sheepName || !body.collarNumber) {
        return error(res, 400, 'Nom de brebis et numéro de collier requis.');
      }

      const config = await readCollarsConfig();
      if (config.data.collars.some((c) => c.collarNumber === body.collarNumber)) {
        return error(res, 409, `Le numéro de collier ${body.collarNumber} existe déjà dans GitHub.`);
      }

      const existingIds = new Set(config.data.collars.map((c) => c.id));
       let id = crypto.randomUUID();
       while (existingIds.has(id)) id = crypto.randomUUID();
      const collarConfig: GithubCollarConfig = {
        id,
        sheepName: body.sheepName,
        collarNumber: body.collarNumber,
        animalNumber: body.animalNumber || undefined,
        color: body.color || '#10B981',
        mode: body.mode === 'real' ? 'real' : 'simulation',
        status: body.status || 'active',
        notes: body.notes || undefined,
        activeZoneId: body.activeZoneId || null,
        baseTransmissionMinutes: Number(body.baseTransmissionMinutes) > 0 ? Number(body.baseTransmissionMinutes) : 30,
      };

      // GitHub est la source de vérité de la configuration du collier.
      const next = { ...config.data, collars: [...config.data.collars, collarConfig] };
      await githubWriteJson(COLLARS_CONFIG_PATH, next, `feat: ajouter le collier ${collarConfig.collarNumber}`);

      try {
        const row = await mirrorCollarToSupabase(supabase, collarConfig, body);
        await queueStandardCadenceCommand(supabase, { id: collarConfig.id, imei: row?.imei || body.imei || null }, Number(row?.standard_cadence_seconds) || 1800);
        if (body.activeZoneId) {
          const zones = await readZonesConfig();
          const zone = zones.data.zones.find((z) => z.id === body.activeZoneId);
          if (zone && !zone.assignedCollarIds.includes(id)) {
            zone.assignedCollarIds = [...zone.assignedCollarIds, id];
            await githubWriteJson(ZONES_CONFIG_PATH, zones.data, `chore: affecter ${collarConfig.collarNumber} à une clôture`);
            await mirrorZoneToSupabase(supabase, zone);
          }
        }
        return res.status(201).json(mapCollar(collarConfig, row, body.activeZoneId));
      } catch (e: any) {
        // Le commit GitHub reste volontairement la trace de la configuration.
        return error(res, 500, 'Collier ajouté à GitHub mais miroir Supabase impossible.', e?.message || e);
      }
    }

    const collarMatch = path.match(/^collars\/([^/]+)$/);
    if (collarMatch && method === 'PUT') {
      const id = collarMatch[1];
      const body = req.body || {};
      const config = await readCollarsConfig();
      const index = config.data.collars.findIndex((c) => c.id === id);
      if (index < 0) return error(res, 404, 'Collier introuvable dans la configuration GitHub.', { id });

      const current = config.data.collars[index];
      const updated: GithubCollarConfig = {
        ...current,
        sheepName: body.sheepName !== undefined ? body.sheepName : current.sheepName,
        collarNumber: body.collarNumber !== undefined ? body.collarNumber : current.collarNumber,
        animalNumber: body.animalNumber !== undefined ? body.animalNumber : current.animalNumber,
        color: body.color !== undefined ? body.color : current.color,
        mode: body.mode !== undefined ? body.mode : current.mode,
        status: body.status !== undefined ? body.status : current.status,
        notes: body.notes !== undefined ? body.notes : current.notes,
        activeZoneId: body.activeZoneId !== undefined ? body.activeZoneId : current.activeZoneId,
        baseTransmissionMinutes: body.baseTransmissionMinutes !== undefined
          ? (Number(body.baseTransmissionMinutes) > 0 ? Number(body.baseTransmissionMinutes) : 30)
          : (Number(current.baseTransmissionMinutes) > 0 ? Number(current.baseTransmissionMinutes) : 30),
      };

      const duplicate = config.data.collars.find((c) => c.id !== id && c.collarNumber === updated.collarNumber);
      if (duplicate) return error(res, 409, `Le numéro de collier ${updated.collarNumber} existe déjà dans GitHub.`);

      config.data.collars[index] = updated;
      await githubWriteJson(COLLARS_CONFIG_PATH, config.data, `chore: modifier le collier ${updated.collarNumber}`);

      try {
        // Les informations techniques restent dans Supabase. Une modification
        // de l'interface ne doit jamais effacer IMEI/ICCID/SIM si ces champs
        // ne sont pas présents dans la requête.
        const { data: existingRow, error: existingError } = await supabase
          .from('collars')
          .select('*')
          .eq('id', id)
          .maybeSingle();
        if (existingError) throw new Error(`Lecture du matériel Supabase impossible : ${existingError.message}`);

        const technicalBody = {
          imei: body.imei !== undefined ? body.imei : existingRow?.imei,
          iccid: body.iccid !== undefined ? body.iccid : existingRow?.iccid,
          simPhone: body.simPhone !== undefined ? body.simPhone : existingRow?.sim_phone,
        };
        const row = await mirrorCollarToSupabase(supabase, updated, technicalBody);
        const standardCadenceSeconds = Math.max(60, Math.round((Number(updated.baseTransmissionMinutes) > 0 ? Number(updated.baseTransmissionMinutes) : 30) * 60));
        const pushStillActive = Boolean(row?.push_expires_at && Date.parse(String(row.push_expires_at)) > Date.now());
        const cadenceUpdate: Record<string, any> = { standard_cadence_seconds: standardCadenceSeconds };
        if (!pushStillActive) {
          cadenceUpdate.active_cadence_seconds = standardCadenceSeconds;
          cadenceUpdate.push_expires_at = null;
        }
        const { data: cadenceRow, error: cadenceError } = await supabase
          .from('collars')
          .update(cadenceUpdate)
          .eq('id', id)
          .select('*')
          .single();
        if (cadenceError) throw new Error(`Mise à jour de la cadence Supabase impossible : ${cadenceError.message}`);
        if (Number(updated.baseTransmissionMinutes) !== Number(current.baseTransmissionMinutes)) {
          await queueStandardCadenceCommand(supabase, { id: updated.id, imei: cadenceRow?.imei || row?.imei || technicalBody.imei || null }, standardCadenceSeconds);
        }
        row.standard_cadence_seconds = cadenceRow?.standard_cadence_seconds ?? standardCadenceSeconds;
        row.active_cadence_seconds = cadenceRow?.active_cadence_seconds ?? row.active_cadence_seconds;
        row.push_expires_at = cadenceRow?.push_expires_at ?? row.push_expires_at;
        if (body.activeZoneId !== undefined) {
          const zones = await readZonesConfig();
          for (const zone of zones.data.zones) {
            zone.assignedCollarIds = (zone.assignedCollarIds || []).filter((collarId) => collarId !== id);
          }
          if (body.activeZoneId) {
            const zone = zones.data.zones.find((z) => z.id === body.activeZoneId);
            if (zone) zone.assignedCollarIds = [...new Set([...zone.assignedCollarIds, id])];
          }
          await githubWriteJson(ZONES_CONFIG_PATH, zones.data, `chore: mettre à jour l'affectation du collier ${updated.collarNumber}`);
          for (const zone of zones.data.zones) await mirrorZoneToSupabase(supabase, zone);
        }
        return res.status(200).json(mapCollar(updated, row, updated.activeZoneId));
      } catch (e: any) {
        return error(res, 500, 'Collier modifié dans GitHub mais miroir Supabase impossible.', e?.message || e);
      }
    }

    if (collarMatch && method === 'DELETE') {
      const id = collarMatch[1];
      const config = await readCollarsConfig();
      const current = config.data.collars.find((c) => c.id === id);
      if (!current) return error(res, 404, 'Collier introuvable dans la configuration GitHub.', { id });

      // Retirer d'abord toutes les affectations de clôtures dans GitHub.
      const zones = await readZonesConfig();
      for (const zone of zones.data.zones) {
        zone.assignedCollarIds = (zone.assignedCollarIds || []).filter((collarId) => collarId !== id);
      }
      await githubWriteJson(ZONES_CONFIG_PATH, zones.data, `chore: retirer le collier ${current.collarNumber} des clôtures`);
      await githubWriteJson(
        COLLARS_CONFIG_PATH,
        { ...config.data, collars: config.data.collars.filter((c) => c.id !== id) },
        `feat: supprimer le collier ${current.collarNumber}`
      );

      // Puis nettoyer les données opérationnelles Supabase.
      const dependentTables = ['command_targets', 'device_events', 'positions', 'alerts', 'collar_zones'];
      for (const table of dependentTables) {
        const { error: depError } = await supabase.from(table).delete().eq('collar_id', id);
        if (depError) return error(res, 400, `GitHub mis à jour mais nettoyage Supabase impossible (${table}).`, depError);
      }
      const { error: dbError } = await supabase.from('collars').delete().eq('id', id);
      if (dbError) return error(res, 400, 'GitHub mis à jour mais suppression Supabase impossible.', dbError);

      for (const zone of zones.data.zones) await mirrorZoneToSupabase(supabase, zone);
      return res.status(200).json({ ok: true, success: true, id, github: true, supabase: true });
    }

    // ---------------- ZONES : GITHUB + SUPABASE ----------------
    if (path === 'zones' && method === 'GET') {
      const config = await readZonesConfig();
      return res.status(200).json(config.data.zones.map(mapZone));
    }

    if (path === 'zones' && method === 'POST') {
      const body = req.body || {};
      if (!body.name) return error(res, 400, 'Nom de la zone requis.');

      let centerLat = Number(body.centerLat) || 0;
      let centerLng = Number(body.centerLng) || 0;
      if (Array.isArray(body.polygonCoords) && body.polygonCoords.length) {
        centerLat = body.polygonCoords.reduce((s: number, p: any) => s + Number(p[0]), 0) / body.polygonCoords.length;
        centerLng = body.polygonCoords.reduce((s: number, p: any) => s + Number(p[1]), 0) / body.polygonCoords.length;
      }

      const config = await readZonesConfig();
      const existingIds = new Set(config.data.zones.map((z) => z.id));
       let id = crypto.randomUUID();
       while (existingIds.has(id)) id = crypto.randomUUID();
      const zone: GithubZoneConfig = {
        id,
        name: body.name,
        description: body.description || '',
        centerLat,
        centerLng,
        radiusMeters: Number(body.radiusMeters) || 500,
        polygonCoords: Array.isArray(body.polygonCoords) ? body.polygonCoords : undefined,
        assignedCollarIds: Array.isArray(body.assignedCollarIds)
          ? (body.assignedCollarIds.includes('all')
              ? (await readCollarsConfig()).data.collars.map((c) => c.id)
              : body.assignedCollarIds.filter((x: any) => x !== 'all'))
          : [],
        color: body.color || '#5A6F4E',
        active: body.active !== false,
        alertOnExit: body.alertOnExit !== false,
        fillVisible: body.fillVisible !== false,
      };

      await githubWriteJson(
        ZONES_CONFIG_PATH,
        { ...config.data, zones: [...config.data.zones, zone] },
        `feat: ajouter la clôture ${zone.name}`
      );
      try {
        await mirrorZoneToSupabase(supabase, zone);
        return res.status(201).json(mapZone(zone));
      } catch (e: any) {
        return error(res, 500, 'Clôture ajoutée à GitHub mais miroir Supabase impossible.', e?.message || e);
      }
    }

    const zoneMatch = path.match(/^zones\/([^/]+)$/);
    if (zoneMatch && method === 'PUT') {
      const id = zoneMatch[1];
      const body = req.body || {};
      const config = await readZonesConfig();
      const index = config.data.zones.findIndex((z) => z.id === id);
      if (index < 0) return error(res, 404, 'Clôture introuvable dans la configuration GitHub.', { id });

      const current = config.data.zones[index];
      let centerLat = body.centerLat !== undefined ? Number(body.centerLat) : current.centerLat;
      let centerLng = body.centerLng !== undefined ? Number(body.centerLng) : current.centerLng;
      if (Array.isArray(body.polygonCoords) && body.polygonCoords.length) {
        centerLat = body.polygonCoords.reduce((s: number, p: any) => s + Number(p[0]), 0) / body.polygonCoords.length;
        centerLng = body.polygonCoords.reduce((s: number, p: any) => s + Number(p[1]), 0) / body.polygonCoords.length;
      }

      const updated: GithubZoneConfig = {
        ...current,
        name: body.name !== undefined ? body.name : current.name,
        description: body.description !== undefined ? body.description : current.description,
        centerLat,
        centerLng,
        radiusMeters: body.radiusMeters !== undefined ? Number(body.radiusMeters) : current.radiusMeters,
        polygonCoords: body.polygonCoords !== undefined ? body.polygonCoords : current.polygonCoords,
        assignedCollarIds: body.assignedCollarIds !== undefined
          ? (Array.isArray(body.assignedCollarIds) ? body.assignedCollarIds.filter((x: any) => x !== 'all') : [])
          : current.assignedCollarIds,
        color: body.color !== undefined ? body.color : current.color,
        active: body.active !== undefined ? Boolean(body.active) : current.active,
        alertOnExit: body.alertOnExit !== undefined ? Boolean(body.alertOnExit) : current.alertOnExit,
        fillVisible: body.fillVisible !== undefined ? Boolean(body.fillVisible) : current.fillVisible !== false,
      };

      config.data.zones[index] = updated;
      await githubWriteJson(ZONES_CONFIG_PATH, config.data, `chore: modifier la clôture ${updated.name}`);
      try {
        await mirrorZoneToSupabase(supabase, updated);
        return res.status(200).json(mapZone(updated));
      } catch (e: any) {
        return error(res, 500, 'Clôture modifiée dans GitHub mais miroir Supabase impossible.', e?.message || e);
      }
    }

    if (zoneMatch && method === 'DELETE') {
      const id = zoneMatch[1];
      const config = await readZonesConfig();
      const current = config.data.zones.find((z) => z.id === id);
      if (!current) return error(res, 404, 'Clôture introuvable dans la configuration GitHub.', { id });

      await githubWriteJson(
        ZONES_CONFIG_PATH,
        { ...config.data, zones: config.data.zones.filter((z) => z.id !== id) },
        `feat: supprimer la clôture ${current.name}`
      );
      const { error: linksError } = await supabase.from('collar_zones').delete().eq('zone_id', id);
      if (linksError) return error(res, 400, 'GitHub mis à jour mais affectations Supabase impossibles à supprimer.', linksError);
      const { error: dbError } = await supabase.from('zones').delete().eq('id', id);
      if (dbError) return error(res, 400, 'GitHub mis à jour mais suppression Supabase impossible.', dbError);
      return res.status(200).json({ ok: true, success: true, id, github: true, supabase: true });
    }

    // ---------------- ALERTS ----------------
    if (path === 'alerts' && method === 'GET') {
      const [{ data, error: dbError }, collarsConfig, zonesConfig] = await Promise.all([
        supabase.from('alerts').select('*').order('created_at', { ascending: false }).limit(200),
        readCollarsConfig(),
        readZonesConfig(),
      ]);
      if (dbError) return error(res, 500, 'Erreur lecture alertes.', dbError.message);

      const collarsById = new Map(collarsConfig.data.collars.map((c) => [c.id, c]));
      const zonesById = new Map(zonesConfig.data.zones.map((z) => [z.id, z]));

      return res.status(200).json((data || []).map((a: any) => {
        const collar = a.collar_id ? collarsById.get(a.collar_id) : undefined;
        const zone = a.zone_id ? zonesById.get(a.zone_id) : undefined;
        return {
          id: a.id,
          collarId: a.collar_id || '',
          sheepName: collar?.sheepName || 'Brebis inconnue',
          collarNumber: collar?.collarNumber || 'Collier inconnu',
          zoneId: a.zone_id || undefined,
          zoneName: zone?.name || undefined,
          timestamp: a.created_at,
          lat: a.latitude ?? 0,
          lng: a.longitude ?? 0,
          type: a.type === 'zone_exit' ? 'EXIT_ZONE' : String(a.type || 'OTHER').toUpperCase(),
          status: a.acknowledged ? 'RESOLVED' : 'ACTIVE',
          message: a.message || 'Alerte sans message.',
        };
      }));
    }

    const resolveMatch = path.match(/^alerts\/([^/]+)\/resolve$/);
    if (resolveMatch && method === 'PUT') {
      const id = resolveMatch[1];
      const { data, error: dbError } = await supabase.from('alerts').update({ acknowledged: true, acknowledged_at: new Date().toISOString() }).eq('id', id).select('*').single();
      if (dbError) return error(res, 400, 'Impossible de résoudre l’alerte.', dbError.message);
      return res.status(200).json({ success: true, alert: data });
    }

    if (path === 'alerts/cleanup' && method === 'DELETE') {
      const { data, error: dbError } = await supabase
        .from('alerts')
        .delete()
        .eq('acknowledged', true)
        .select('id');
      if (dbError) return error(res, 400, 'Impossible de nettoyer les alertes acquittées.', dbError.message);
      return res.status(200).json({ ok: true, success: true, deleted: data?.length || 0 });
    }

    // ---------------- HISTORY ----------------
    if (path === 'history' && method === 'GET') {
      let q = supabase.from('positions').select('*, collars(*)').order('recorded_at', { ascending: true });
      if (query.collarId && query.collarId !== 'all') q = q.eq('collar_id', query.collarId);
      if (query.startDate) q = q.gte('recorded_at', query.startDate);
      if (query.endDate) q = q.lte('recorded_at', query.endDate);
      const { data, error: dbError } = await q.limit(10000);
      if (dbError) return error(res, 500, 'Erreur lecture historique.', dbError.message);
      return res.status(200).json((data || []).map((p: any) => ({
        id: p.id,
        collarId: p.collar_id,
        sheepName: p.collars?.animal_name || p.collars?.name || '',
        collarNumber: p.collars?.internal_code || '',
        color: p.collars?.color || '#5A6F4E',
        lat: p.latitude,
        lng: p.longitude,
        timestamp: p.recorded_at,
        speedKmH: p.speed ? p.speed * 3.6 : 0,
        battery: p.battery_percent ?? 0,
        inZone: true,
      })));
    }

    // ---------------- PUSH ----------------
    if (path === 'push-order' && method === 'POST') {
      const body = req.body || {};
      const collarIds = Array.isArray(body.collarIds) ? body.collarIds : [];
      const durationMinutes = Number(body.durationMinutes);
      const intervalSeconds = Number(body.intervalSeconds);
      if (!durationMinutes || durationMinutes <= 0) return error(res, 400, 'Durée valide requise en minutes.');
      if (!(Number.isInteger(intervalSeconds) && intervalSeconds >= 60 && intervalSeconds <= 86400)) return error(res, 400, 'Cadence PUSH invalide. Utilisez 5, 10, 15, 30 minutes ou une valeur personnalisée en minutes.');

      // Le PUSH est piloté par Supabase : GitHub ne doit pas pouvoir bloquer
      // une commande opérationnelle à cause d'un rate-limit ou d'une indisponibilité.
      const { data: collarRows, error: collarLookupError } = await supabase
        .from('collars')
        .select('id, imei')
        .order('created_at', { ascending: true });
      if (collarLookupError) return error(res, 400, 'Impossible de lire les colliers dans Supabase.', collarLookupError);

      const availableIds = new Set((collarRows || []).map((row: any) => String(row.id)));
      let targets = collarIds
        .filter((id: any) => id !== 'all' && availableIds.has(String(id)))
        .map((id: any) => String(id)) as string[];
      if (collarIds.includes('all')) targets = (collarRows || []).map((row: any) => String(row.id));
      targets = [...new Set(targets)];
      if (!targets.length) return error(res, 400, 'Aucun collier valide sélectionné pour le PUSH.');

      const expiresAt = new Date(Date.now() + durationMinutes * 60_000).toISOString();
      const payload = {
        type: 'push',
        intervalSeconds,
        durationMinutes,
        expiresAt,
        delivery: 'next_wakeup',
        instruction: 'Au prochain réveil, appliquer la cadence temporaire puis revenir à la cadence standard.',
      };

      const { data: command, error: commandError } = await supabase.from('commands').insert({
        command_type: 'push',
        cadence_seconds: intervalSeconds,
        duration_minutes: durationMinutes,
        target_mode: collarIds.includes('all') ? 'all' : 'selected',
        status: 'pending',
        payload,
      }).select('*').single();
      if (commandError) return error(res, 400, 'Impossible de créer la commande PUSH.', commandError.message);

      const { data: targetCollars, error: targetLookupError } = await supabase
        .from('collars')
        .select('id, imei')
        .in('id', targets);
      if (targetLookupError) return error(res, 400, 'Commande PUSH créée mais les matériels cibles sont introuvables.', targetLookupError);

      const byId = new Map((targetCollars || []).map((row: any) => [row.id, row]));
      const targetRows = targets.map((collarId) => {
        const imei = byId.get(collarId)?.imei || null;
        return {
          command_id: command.id,
          collar_id: collarId,
          status: 'pending',
          delivery_status: 'queued',
          mqtt_topic: imei ? `paturgps/${imei}/command` : null,
          mqtt_payload: { ...payload, collarId, imei },
        };
      });

      const { error: targetError } = await supabase.from('command_targets').insert(targetRows);
      if (targetError) return error(res, 400, 'Commande PUSH créée mais cibles impossibles à enregistrer.', targetError);

      const { error: cadenceError } = await supabase
        .from('collars')
        .update({ active_cadence_seconds: intervalSeconds, push_expires_at: expiresAt })
        .in('id', targets);
      if (cadenceError) return error(res, 400, 'Commande PUSH créée mais état de cadence impossible à mettre à jour.', cadenceError);

      return res.status(200).json({
        ok: true,
        success: true,
        message: `Ordre PUSH mis en file pour ${targets.length} collier(s). Il sera récupéré au prochain réveil.`,
        commandId: command.id,
        targets,
        intervalSeconds,
        durationMinutes,
        expiresAt,
        delivery: 'next_wakeup',
      });
    }

    // Stop = une nouvelle commande, elle aussi récupérée au prochain réveil.
    const pushStopMatch = path.match(/^collars\/([^/]+)\/push$/);
    if (pushStopMatch && method === 'DELETE') {
      const collarId = pushStopMatch[1];
      const { data: command, error: commandError } = await supabase.from('commands').insert({
        command_type: 'stop',
        target_mode: 'selected',
        status: 'pending',
        payload: { type: 'stop_push', delivery: 'next_wakeup' },
      }).select('*').single();
      if (commandError) return error(res, 400, 'Impossible de créer l’ordre d’arrêt PUSH.', commandError.message);
      const { data: targetCollar } = await supabase.from('collars').select('imei').eq('id', collarId).maybeSingle();
      const { error: targetError } = await supabase.from('command_targets').insert({
        command_id: command.id,
        collar_id: collarId,
        status: 'pending',
        delivery_status: 'queued',
        mqtt_topic: targetCollar?.imei ? `paturgps/${targetCollar.imei}/command` : null,
        mqtt_payload: { type: 'stop_push', delivery: 'next_wakeup', collarId, imei: targetCollar?.imei || null },
      });
      if (targetError) return error(res, 400, 'Ordre d’arrêt créé mais cible impossible à enregistrer.', targetError);
      const { data: collarRow, error: collarLookupError } = await supabase
        .from('collars')
        .select('standard_cadence_seconds')
        .eq('id', collarId)
        .maybeSingle();
      if (collarLookupError) return error(res, 400, 'Ordre d’arrêt créé mais lecture de la cadence standard impossible.', collarLookupError);
      const standardCadenceSeconds = Number(collarRow?.standard_cadence_seconds);
      if (!Number.isFinite(standardCadenceSeconds) || standardCadenceSeconds < 60) return error(res, 400, 'Cadence standard du collier invalide.', { collarId });
      const { error: cadenceError } = await supabase
        .from('collars')
        .update({ active_cadence_seconds: Math.round(standardCadenceSeconds), push_expires_at: null })
        .eq('id', collarId);
      if (cadenceError) return error(res, 400, 'Ordre d’arrêt créé mais cadence impossible à restaurer.', cadenceError);
      return res.status(200).json({ ok: true, success: true, message: 'Arrêt PUSH mis en file pour le prochain réveil.', commandId: command.id });
    }

    // ---------------- DEVICE / MQTT INGESTION PREPARATION ----------------
    // Le BG95/MQTT pourra poster ici avec l'IMEI. Vercel retrouvera le collier
    // dans Supabase et stockera la télémétrie. Cette route reste volontairement
    // minimale tant que le firmware BG95 n'est pas défini.
    if (path === 'telemetry' && method === 'POST') {
      const body = req.body || {};
      const imei = String(body.imei || '').trim();
      if (!imei) return error(res, 400, 'IMEI requis pour une télémétrie.');

      const { data: collar, error: collarError } = await supabase.from('collars').select('*').eq('imei', imei).maybeSingle();
      if (collarError) return error(res, 400, 'Recherche du collier par IMEI impossible.', collarError);
      if (!collar) return error(res, 404, 'IMEI inconnu dans Supabase.', { imei });

      const lat = Number(body.latitude);
      const lng = Number(body.longitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return error(res, 400, 'Latitude/longitude invalides.');

      const { position, zoneCheck, batteryCheck } = await ingestPosition(supabase, collar, {
        latitude: lat,
        longitude: lng,
        altitude: body.altitude ?? null,
        accuracy: body.accuracy ?? null,
        speed: body.speed ?? null,
        heading: body.heading ?? null,
        batteryPercent: body.batteryPercent ?? null,
        signalStrength: body.signalStrength ?? null,
        recordedAt: body.recordedAt || null,
        source: 'mqtt',
      });

      return res.status(201).json({ ok: true, collarId: collar.id, imei, positionId: position.id, zoneCheck, batteryCheck });
    }

    // ---------------- SAISIE MANUELLE D'UNE POSITION (depuis l'app) ----------------
    // Tant que le worker MQTT/BG95 n'est pas branché, c'est le moyen recommandé
    // d'enregistrer une position reçue du collier (SMS, appel...) : contrairement
    // à une insertion directe dans Supabase Studio, cette route déclenche bien
    // le contrôle hors-zone et le contrôle batterie faible.
    const manualPositionMatch = path.match(/^collars\/([^/]+)\/position$/);
    if (manualPositionMatch && method === 'POST') {
      const collarId = manualPositionMatch[1];
      const body = req.body || {};

      const lat = Number(body.latitude);
      const lng = Number(body.longitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return error(res, 400, 'Latitude/longitude invalides.');

      const { data: collar, error: collarError } = await supabase.from('collars').select('*').eq('id', collarId).maybeSingle();
      if (collarError) return error(res, 400, 'Recherche du collier impossible.', collarError);
      if (!collar) return error(res, 404, 'Collier introuvable.', { collarId });

      const batteryPercent = body.batteryPercent !== undefined && body.batteryPercent !== null && body.batteryPercent !== ''
        ? Number(body.batteryPercent)
        : null;
      if (batteryPercent != null && (!Number.isFinite(batteryPercent) || batteryPercent < 0 || batteryPercent > 100)) {
        return error(res, 400, 'Batterie invalide (0 à 100).');
      }

      const { position, zoneCheck, batteryCheck } = await ingestPosition(supabase, collar, {
        latitude: lat,
        longitude: lng,
        batteryPercent,
        recordedAt: body.recordedAt || null,
        source: 'manual',
      });

      return res.status(201).json({ ok: true, collarId: collar.id, positionId: position.id, zoneCheck, batteryCheck });
    }

    // ---------------- SIMULATION ----------------
    if (path === 'simulation/trigger-out-of-zone' && method === 'POST') {
      const body = req.body || {};
      const { data: collar } = await supabase.from('collars').select('*').eq('id', body.collarId).single();
      if (!collar) return error(res, 404, 'Collier introuvable.');
      const lat = Number(collar.last_latitude || 42.9637) + 0.012;
      const lng = Number(collar.last_longitude || 0.3829) + 0.012;
      await supabase.from('collars').update({ last_latitude: lat, last_longitude: lng, last_seen: new Date().toISOString() }).eq('id', collar.id);
      const { data: alert } = await supabase.from('alerts').insert({
        collar_id: collar.id,
        type: 'zone_exit',
        severity: 'warning',
        message: `ALERTE DÉCLENCHÉE : ${collar.animal_name || collar.name} a dépassé la zone de sécurité.`,
        latitude: lat,
        longitude: lng,
      }).select('*').single();
      return res.status(200).json({ ok: true, success: true, collar: { id: collar.id, currentLat: lat, currentLng: lng }, alert });
    }

    return error(res, 404, `Route API inconnue : /api/${path}`, { method, path, url: req.url || null });
  } catch (e: any) {
    return error(res, 500, 'Erreur serveur Pâtur’GPS V12.', e?.message || e);
  }
}
